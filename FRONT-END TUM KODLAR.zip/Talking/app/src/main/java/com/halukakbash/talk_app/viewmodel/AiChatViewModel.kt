package com.halukakbash.talk_app.viewmodel

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AiChatViewModel : ViewModel() {
    // Add any required functionality here
    // For example, handling message sending, receiving AI responses, etc.
    
    fun sendMessage(message: String) {
        // Implement message sending logic
    }
    
    fun getAiResponse(message: String) {
        // Implement AI response logic
    }
} 