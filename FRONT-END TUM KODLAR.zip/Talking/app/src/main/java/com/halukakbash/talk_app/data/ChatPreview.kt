package com.halukakbash.talk_app.data

data class ChatPreview(
    val chatId: String,
    val otherUser: User,
    val lastMessage: String,
    val lastMessageTime: Long,
    val lastMessageSenderId: String,
    val unreadCount: Int = 0,
    val lastReadMessageId: String = ""
) 