package com.halukakbash.talk_app.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.halukakbash.talk_app.data.User
import com.halukakbash.talk_app.data.LanguageLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.flow.asStateFlow

class HomeViewModel : ViewModel() {
    private val firestore = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()
    
    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private var allUsers = listOf<User>()

    init {
        setupPresence()
        loadUsers()
    }

    private fun setupPresence() {
        auth.currentUser?.let { user ->
            val userStatusRef = firestore.collection("users").document(user.uid)
            userStatusRef.update(mapOf(
                "isOnline" to true,
                "lastSeen" to System.currentTimeMillis()
            ))
        }
    }

    private fun loadUsers() {
        viewModelScope.launch {
            try {
                val currentUserId = auth.currentUser?.uid
                firestore.collection("users")
                    .whereNotEqualTo("id", currentUserId)
                    .addSnapshotListener { snapshot, e ->
                        if (e != null) {
                            return@addSnapshotListener
                        }

                        val usersList = snapshot?.documents?.mapNotNull { doc ->
                            doc.toObject(User::class.java)
                        } ?: emptyList()
                        
                        allUsers = usersList
                        _users.value = usersList
                    }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun filterByLanguageLevel(level: String?) {
        viewModelScope.launch {
            try {
                if (level == null) {
                    _users.value = allUsers
                    return@launch
                }

                val selectedLevels = level.split(",")
                val filteredUsers = allUsers.filter { user ->
                    selectedLevels.any { level ->
                        user.languageLevel.startsWith(level, ignoreCase = true)
                    }
                }
                
                _users.value = filteredUsers
            } catch (e: Exception) {
                println("DEBUG: Error filtering users: ${e.message}")
                e.printStackTrace()
            }
        }
    }

    fun clearFilter() {
        _users.value = allUsers
    }
} 