package com.halukakbash.talk_app.viewmodel

import androidx.lifecycle.ViewModel

class QuizViewModel : ViewModel() {
    // Add quiz-related functionality here
} 